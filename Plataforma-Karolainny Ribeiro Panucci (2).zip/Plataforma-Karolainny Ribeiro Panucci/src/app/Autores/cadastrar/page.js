'use client';

import CardAutor from "@/componentes/CardAutor";
import { PlayCircle,Home as Homeicon, Users, UserPlus, ListVideo } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";


const Cadastar=()=>{
    const router = useRouter();
    const [autor, setAutor] = useState([]);
    const [autores, setAutores] = useState([]);
    useEffect(()=>{
        if(typeof window !== 'undefined'){
          const listaDeAutores= localStorage.getItem('autores');
             
          if(listaDeAutores !== null){
              try{
                  setAutores(JSON.parse(listaDeAutores));
              } catch(error){
                  console.error(error);
              }
          }
          
        }
  
      },[]);
      const handleOnChange=(e)=>{
        const{id, value}= e.target;
        setAutor({...autor,
        [id]:value
    });
};




    const handleSave=(e)=>{
        e.preventDefault();
        const UpdateAutores=[...autores];
        UpdateAutores.push({
            id: Math.random().toString(36).slice(2,7),
            ...autor
        });
        setAutores
        (UpdateAutores);
        localStorage.setItem(autores, JSON.stringify(UpdateAutores));
        alert(`${autor.nome} cadastrado com sucesso!`)
        setAutor({});
    }
return(
<>

<div className="h-screen flex flex-col">
      <header className="bg-slate-900 h-20 flex items-center p-6  ">
        <PlayCircle/> <h1 className="font-semibold">KP.video</h1>
       </header>
      <div className="flex flex-1">
        <aside className="w-72 bg-slate-500 p-6 gap-8 fixed h-full">
          <nav>
            <a 
            href="/"
            className="flex items-center gap-3 text-sm font-semibold hover: text-blue-200">
                <Homeicon/>
                Home

            </a>
            <a 
            href="/Autores"
            className="flex items-center gap-3 text-sm font-semibold hover: text-blue-200">
                <Users/>
            Autores

            </a>
            <a 
            href="/Autores/cadastrar"
            className="flex items-center gap-3 text-sm font-semibold hover: text-blue-200">
                <UserPlus/>
                Adicionar Autor

            </a>
            <a 
            href="/videos"
            className="flex items-center gap-3 text-sm font-semibold hover: text-blue-200">
                <ListVideo/>
                Videos

            </a>
            <a 
            href="/videos/cadastrar"
            className="flex items-center gap-3 text-sm font-semibold hover: text-blue-200">
                <PlayCircle/>
                Adicionar Video

            </a>
          </nav>
        </aside>
        <main className="flex flex-col flex-1 p-6">
        <h2 className="font-semibold text-2xl self-center ">Cadastrado De Novos Videos</h2>
            <form 
            onSubmit={(e)=> handleSave(e)} 
            className="flex flex-col gap-5 w-ful self-center max-w-2xl mt-10"
            >
              <div className="">

                  <label
                  htmlFor= "nome"
                  className="block text-slate-600 text-sm font-bold mb-2"
                  >
                    Nome:
                  </label>
                  <input 
                   autoFocus
                   className="bg-slate-900 appearance-none w-full py-2 px-4 text-zinc-200 leading-tight focus: outline-none focus:bg-black/20 transition-colors"
                   type="text"
                   id="nome"
                   placeholder="nome completo"
                   value={autor.nome}
                   onChange={(e) => handleOnChange(e)}
                   required 
                  />

             </div>
              <div className="">

                  <label
                  htmlFor= "canal"
                  className="block text-slate-600 text-sm font-bold mb-2"
                  >
                    Canal
                  </label>
                  <input 
                   autoFocus
                   className="bg-slate-900 appearance-none w-full py-2 px-4 text-zinc-200 leading-tight focus: outline-none focus:bg-black/20 transition-colors"
                   type="text"
                   id="canal"
                   placeholder="nome do canal"
                   value={autor.canal}
                   onChange={(e) => handleOnChange(e)}
                   required 
                  />
                  </div>
                      <div className="">

                  <label
                  htmlFor= "nome"
                  className="block text-slate-600 text-sm font-bold mb-2"
                  >
                    Nome:
                  </label>
                  <input 
                   autoFocus
                   className="bg-slate-900 appearance-none w-full py-2 px-4 text-zinc-200 leading-tight focus: outline-none focus:bg-black/20 transition-colors"
                   type="text"
                   id="nome"
                   placeholder="nome completo"
                   value={autor.nome}
                   onChange={(e) => handleOnChange(e)}
                   required 
                  />

             </div>
              <div className="">

                  <label
                  htmlFor= "canal"
                  className="block text-slate-600 text-sm font-bold mb-2"
                  >
                    Canal
                  </label>
                  <input 
                   autoFocus
                   className="bg-slate-900 appearance-none w-full py-2 px-4 text-zinc-200 leading-tight focus: outline-none focus:bg-black/20 transition-colors"
                   type="text"
                   id="canal"
                   placeholder="nome do canal"
                   value={autor.canal}
                   onChange={(e) => handleOnChange(e)}
                   required 
                  />

             </div>
             <button className=" bg-teal-600 hover: border-teal-800 text-base border-4 text-white py-1 px-2 rounded">
            Adicionar

        </button>

              
            </form>
        </main>
      </div>
        
  </div>
  

    
    
    


</>
)
};
export default Cadastar;
