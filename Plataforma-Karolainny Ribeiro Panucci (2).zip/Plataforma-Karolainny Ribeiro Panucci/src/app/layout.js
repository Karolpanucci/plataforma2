

import './globals.css'


export const metadata = {
  title: 'KP videos',
  description: 'Paltaforma de videos e musicas',
}

export default function RootLayout({ children }) {
  return (
    <html lang="pt-br">
      <body className='bg-zinc-200 text-blue-600'>
     
            {children}
         
      </body>
    </html>
  )
}
