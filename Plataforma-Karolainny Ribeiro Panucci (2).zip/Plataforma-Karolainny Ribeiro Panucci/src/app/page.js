'use client';
import { useEffect,useState } from "react";
import {data} from'./utils'
import React from "react";
import"src/app/globals.css"
import {
    Home as Homeicon,
    ListVideo,
    PlayCircle,
    UserPlus,
    Users    
} from 'lucide-react'
import CardAutor from "@/componentes/CardAutor";
import CardVideo from "@/componentes/CardVideo";



const Home = ()=> {
   const [autores, setAutores] = useState([]);
   const[videos, setVideos]= useState([]);
   
   useEffect(() =>{
    const listaDeAutores = localStorage.getItem('autores')||
    localStorage.setItem(autores, JSON(data))
    const listaDeVideos =  
    localStorage.getItem('videos')|| localStorage.setItem(videos, JSON(data))
    
    if(listaDeVideos !==null){
      try{
       setVideos(JSON.parse(listaDeVideos));
      } catch(error){
        console.error( error);
      }
    }

    if (listaDeAutores !==null){
      try{
        setAutores(JSON.parse(listaDeAutores));
      } catch(error){
        console.error(error);
      }
    }

   }, [])

  return (<>
  <div className="h-screen flex flex-col">
      <header className="bg-slate-900 h-20 flex items-center p-6  ">

        <PlayCircle/> <h1 className="font-semibold">KP.video</h1>
       </header>
      <div className="flex flex-1">
        <aside className="w-72 bg-slate-500 p-6 gap-8 fixed h-full">
          <nav>
            <a 
            href="/"
            className="flex items-center gap-3 text-sm font-semibold hover: text-blue-200">
                <Homeicon/>
                Home

            </a>
            <a 
            href="/Autores"
            className="flex items-center gap-3 text-sm font-semibold hover: text-blue-200">
                <Users/>
            Autores

            </a>
            <a 
            href="/Autores/cadastrar"
            className="flex items-center gap-3 text-sm font-semibold hover: text-blue-200">
                <UserPlus/>
                Adicionar Autor

            </a>
            <a 
            href="/videos"
            className="flex items-center gap-3 text-sm font-semibold hover: text-blue-200">
                <ListVideo/>
                Videos

            </a>
            <a 
            href="/videos/cadastrar"
            className="flex items-center gap-3 text-sm font-semibold hover: text-blue-200">
                <PlayCircle/>
                Adicionar Video

            </a>
          </nav>
        </aside>
        <main className="flex flex-col flex-1 p-6">
          <h2 className="font-semiol text-2xl"> Ultimos Autores Adicionador</h2>
          <section className="grid grid-cols-3 gap-6 mt-4">
           {autores .map((item, index, array)=>{
            if(array.length-index<=6){
              return <CardAutor key={item.id} autor={item}/>
            }
            return'';
           })}
          </section>
            

          <h2 className="font-semiol text-2xl mt-10"> Ultimos Videos Adicionador</h2>
          <section className="grid grid-cols-3 gap-6 mt-4">
            {videos .map((item, index, array)=>{

              if(array.length - index <=6 ){
                return<CardVideo  key={item.id} video={item}/> 
              }

              return'';
            })}
          </section>
        </main>
      </div>
        
  </div>

  </>)
};
export default Home;
