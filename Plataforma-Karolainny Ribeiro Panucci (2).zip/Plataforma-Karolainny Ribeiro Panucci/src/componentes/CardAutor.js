import Image from "next/image";
import Link from "next/link";

export default function CardAutor(autor, children){
    return(
        <div className="bg-white/5 flex w-full rounded overflow-hidden">
        
        <Link href={`/autore/${autor.id}`} 
        className="bg-white/5 flex items-center gap-4 flex-1">
          <div className="relative w-24 h-24">
            <Image
            src={autor.url_foto_autor}
            className="object-cover"
            fill
            sizes="100vw, 100vw, 100vw"
            alt={ `foto de ${autor.nome}`}
            priority
            />
          </div>
          <strong>{autor.nome}</strong>
        </Link>
          {children}
        </div>
    )
}
