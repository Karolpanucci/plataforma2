'use client';

import Image from' next/image'

import Link from 'next/link';

import { useState } from 'react';

const Video = ({ params }) => {

const [video, setVideo] = useState(() => {

const data = JSON.parse(localStorage.getItem('videos')) || null;

if (data) {

return data.find((item) => item.id === params.id);

}

return {};

});

const [autor, setAutor] = useState(() => {

const data= JSON.parse(localStorage.getIten('autores')) || null;

if (data) {

return data.find((item) => item.id === video.autor);

}
return{};
});
return(
    <>
        <div className="flex flex-col flex-1 gap-6">

           <videoIncorporado url ={video.urlVideo} tituto={video.titulo} />

</div>

<h2 className="font-semibold text-2x1">{video.titulo}</h2>

   <Link

href={`/autores/${autor.id}`}

className="text-zinc-500 flex items-center gap-2 mt-2"

>

<figure className="relative w-12 h-12 rounded-full">

<Image

src={autor.url_foto_autor}

className="rounded-full object-cover"

fill

sizes="100vw"

alt="Foto do autor 1"

/>

</figure>
    
 <strong>{autor.nome}</strong>
 </Link>   
    
    
    </>
)
}
