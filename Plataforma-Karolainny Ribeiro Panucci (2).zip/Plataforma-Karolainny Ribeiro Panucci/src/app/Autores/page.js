'use client';
import CardAutor from "@/componentes/CardAutor";
import { useEffect, useState } from "react";
import { PlayCircle,Home as Homeicon, Users, UserPlus, ListVideo } from "lucide-react";


const Listar=()=>{
    const[autores, setAutores]= useState([]);

    useEffect(() =>{
        const listaDeAutores = localStorage.getItem('autore') || null;
        if(listaDeAutores !== null){
            try{
                setAutores(JSON.parse(listaDeAutores));
            } catch (error){
                console.error(error);
            }

        }
    },[]);
    return(<>
      <body className="h-screen flex flex-col">
      <header className="bg-slate-900 h-20 flex items-center p-6  ">
        <PlayCircle/> <h1 className="font-semibold">KP.video</h1>
       </header>
      <div className="flex flex-1">
        <aside className="w-72 bg-slate-500 p-6 gap-8 fixed h-full">
          <nav>
            <a 
            href="/"
            className="flex items-center gap-3 text-sm font-semibold hover: text-blue-200">
                <Homeicon/>
                Home

            </a>
            <a 
            href="/Autores"
            className="flex items-center gap-3 text-sm font-semibold hover: text-blue-200">
                <Users/>
            Autores

            </a>
            <a 
            href="/Autores/cadastrar"
            className="flex items-center gap-3 text-sm font-semibold hover: text-blue-200">
                <UserPlus/>
                Adicionar Autor

            </a>
            <a 
            href="/videos"
            className="flex items-center gap-3 text-sm font-semibold hover: text-blue-200">
                <ListVideo/>
                Videos

            </a>
            <a 
            href="/videos/cadastrar"
            className="flex items-center gap-3 text-sm font-semibold hover: text-blue-200">
                <PlayCircle/>
                Adicionar Video

            </a>
          </nav>
        </aside>
        <main className="flex flex-col flex-1 p-6">
        <h2 className="font-semibold text-2xl self-center">Lista De Autores</h2>
           
       <section  className="flex flex-col gap-6 w-full self-center max-w-2xl mt-10">
           {autores .map((item) =>{
            return(
                <CardAutor key={item.id} autor={item}>
                    <div className="bg-whitw/10 fle flex-col h-full">
                        <button className="h1/2">Alterar</button>
                        <button className="h-1/2 bg-red-900">Excluir</button>
                    </div>

                </CardAutor> );

           })}
       </section>




        </main>
      </div>
        
       </body>
    
    
    
    </>);
};
export default Listar;