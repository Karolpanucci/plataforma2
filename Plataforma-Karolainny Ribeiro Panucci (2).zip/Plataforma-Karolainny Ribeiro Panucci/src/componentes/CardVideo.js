import Image from "next/image";
import Link from "next/link";
import { useState } from "react";

export default function CardVideo(video, children){
     const[autor, setAutor] = useState(()=>{
      const data= JSON.parse(localStorage.getItem('autor')) || null;
      if(data !==null){
        return data.find((item)=> item.id === video.autor);
      }
    
      return{};
    
     });
    return(<>
        <Link
        href={`/videos/${video.id}`}
        className="bg-whitww/5 flex flex-col p-3 w-full h-80 rounded overflow-hidden flex-1">
           <div className="relative w-full h3/5">
            <Image 
            src={video.urlCapaVideo}
            className="object-cover rounded"
            fill
            sizes="100wv, 100wv, 100wv"
            alt={`Foto de capa do Video ${video.titulo}`}
            priority
            />
            </div>
            <strong className="text-sm font-semibold mt-4">{video.titulo}</strong>
            <span className="text-sm text-zinc-500 mt-2">{autor.nome}</span>

        </Link>
        {children}
     </>)
}
